<?php
echo 'Hello PHP';
?>